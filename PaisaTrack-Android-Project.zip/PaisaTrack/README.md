# PaisaTrack — Android expense and income tracker

Offline-first personal finance app built with Kotlin, Jetpack Compose, Room and SQLite.

## Features
- Record income and expenses
- INR amounts stored as integer paise
- Expense categories and income categories
- Cash, UPI, debit card, credit card, bank transfer and other payment methods
- Custom transaction dates
- Edit and delete transactions
- Dashboard with current-month income, expenses, net balance and budget progress
- Category spending breakdown
- Transaction search, type filters, current-week/current-month/all-time filters
- Weekly and monthly reports with daily expense bars and category totals
- JSON backup and restore using Android's document picker
- No sign-in, bank connection or internet permission

## Open and run
1. Extract this ZIP.
2. Open the `PaisaTrack` folder in Android Studio.
3. Use JDK 17.
4. Install Android SDK Platform 36 if Android Studio requests it.
5. Sync Gradle, then run the `app` configuration on an emulator or connected Android device.

## Backup and restore
Use Settings → Export backup to save a JSON backup. Restore from backup replaces the app's current transactions, so export a backup first if you need to preserve them.

## Notes
This is a source project, not a prebuilt APK. Build and test it in Android Studio before relying on it for important records. The app stores data locally; uninstalling the app or clearing its storage can remove local records. Keep backups in a safe location.

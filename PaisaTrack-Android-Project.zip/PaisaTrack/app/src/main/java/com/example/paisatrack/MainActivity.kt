package com.example.paisatrack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.paisatrack.data.Transaction
import com.example.paisatrack.viewmodel.TransactionViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val expenseCategories = listOf(
    "Food", "Transport", "Shopping", "Bills", "Health",
    "Education", "Entertainment", "Travel", "Personal", "Other"
)
private val incomeCategories = listOf("Salary", "Pocket money", "Business", "Gift", "Interest", "Other")
private val paymentMethods = listOf("Cash", "UPI", "Debit Card", "Credit Card", "Bank Transfer", "Other")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PaisaTrackApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaisaTrackApp(vm: TransactionViewModel = viewModel()) {
    val transactions by vm.transactions.collectAsState()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("paisatrack_settings", 0) }
    var budget by remember { mutableLongStateOf(prefs.getLong("monthly_budget", 2000000L)) }
    var tab by remember { mutableStateOf("Home") }
    var editorItem by remember { mutableStateOf<Transaction?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var showRestoreConfirm by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val array = JSONArray()
                transactions.forEach { t ->
                    array.put(JSONObject().apply {
                        put("amountPaise", t.amountPaise)
                        put("type", t.type)
                        put("category", t.category)
                        put("paymentMethod", t.paymentMethod)
                        put("note", t.note)
                        put("occurredAt", t.occurredAt)
                    })
                }
                val root = JSONObject().put("format", "PaisaTrackBackup").put("version", 1)
                    .put("transactions", array)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(root.toString(2)) }
                    ?: error("Could not write backup file")
                snackbarMessage = "Backup saved"
            }.onFailure { snackbarMessage = "Backup failed: ${it.message}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Could not read selected file")
                val root = JSONObject(text)
                require(root.optString("format") == "PaisaTrackBackup") { "This is not a PaisaTrack backup" }
                val array = root.getJSONArray("transactions")
                val restored = buildList {
                    for (i in 0 until array.length()) {
                        val o = array.getJSONObject(i)
                        add(Transaction(
                            amountPaise = o.getLong("amountPaise"),
                            type = o.getString("type"),
                            category = o.getString("category"),
                            paymentMethod = o.optString("paymentMethod", "Other"),
                            note = o.optString("note"),
                            occurredAt = o.getLong("occurredAt")
                        ))
                    }
                }
                require(restored.all { it.amountPaise > 0 && it.type in listOf("INCOME", "EXPENSE") }) {
                    "Backup contains invalid transactions"
                }
                vm.restore(restored)
                snackbarMessage = "Backup restored (${restored.size} records)"
            }.onFailure { snackbarMessage = "Restore failed: ${it.message}" }
        }
    }

    val now = Calendar.getInstance()
    val monthItems = transactions.filter { it.occurredAt.isSameMonth(now) }
    val income = monthItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
    val expense = monthItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
    val balance = income - expense

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF176B52),
            secondary = androidx.compose.ui.graphics.Color(0xFF55796B),
            tertiary = androidx.compose.ui.graphics.Color(0xFFB7791F)
        )
    ) {
        val snackbarHostState = remember { SnackbarHostState() }
        LaunchedEffect(snackbarMessage) {
            snackbarMessage?.let {
                snackbarHostState.showSnackbar(it)
                snackbarMessage = null
            }
        }
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PaisaTrack", fontWeight = FontWeight.Bold)
                            Text("Personal finance, made simple", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        TextButton(onClick = { exportLauncher.launch("paisatrack-backup.json") }) {
                            Text("Backup")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Transactions", "Reports", "Settings").forEach { label ->
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = { tab = label },
                            icon = {
                                Text(
                                    when (label) {
                                        "Home" -> "⌂"
                                        "Transactions" -> "≡"
                                        "Reports" -> "▥"
                                        else -> "⚙"
                                    }
                                )
                            },
                            label = { Text(label) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab != "Settings") FloatingActionButton(onClick = {
                    editorItem = null
                    showEditor = true
                }) { Text("+", style = MaterialTheme.typography.headlineMedium) }
            }
        ) { padding ->
            when (tab) {
                "Home" -> DashboardScreen(
                    modifier = Modifier.padding(padding),
                    income = income, expense = expense, balance = balance,
                    budget = budget, items = transactions,
                    onAdd = { editorItem = null; showEditor = true },
                    onOpenTransactions = { tab = "Transactions" },
                    onEdit = { editorItem = it; showEditor = true }
                )
                "Transactions" -> TransactionsScreen(
                    modifier = Modifier.padding(padding),
                    items = transactions,
                    onEdit = { editorItem = it; showEditor = true },
                    onDelete = { vm.delete(it); snackbarMessage = "Transaction deleted" }
                )
                "Reports" -> ReportsScreen(
                    modifier = Modifier.padding(padding), items = transactions
                )
                else -> SettingsScreen(
                    modifier = Modifier.padding(padding),
                    budget = budget,
                    onBudget = { showBudgetDialog = true },
                    onBackup = { exportLauncher.launch("paisatrack-backup.json") },
                    onRestore = { showRestoreConfirm = true }
                )
            }
        }
    }

    if (showEditor) {
        TransactionEditor(
            existing = editorItem,
            onDismiss = { showEditor = false },
            onSave = { vm.save(it); showEditor = false; snackbarMessage = "Transaction saved" }
        )
    }

    if (showBudgetDialog) {
        var amount by remember(budget) { mutableStateOf((budget / 100.0).toString()) }
        AlertDialog(
            onDismissRequest = { showBudgetDialog = false },
            title = { Text("Monthly expense budget") },
            text = {
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("Budget (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    amount.toPaiseOrNull()?.takeIf { it > 0 }?.let {
                        budget = it
                        prefs.edit().putLong("monthly_budget", it).apply()
                    }
                    showBudgetDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showBudgetDialog = false }) { Text("Cancel") } }
        )
    }

    if (showRestoreConfirm) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirm = false },
            title = { Text("Restore backup?") },
            text = { Text("Restoring replaces all current transactions. Export a backup first if you want to keep the current data.") },
            confirmButton = {
                TextButton(onClick = {
                    showRestoreConfirm = false
                    importLauncher.launch(arrayOf("application/json", "text/json", "*/*"))
                }) { Text("Choose backup") }
            },
            dismissButton = { TextButton(onClick = { showRestoreConfirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun DashboardScreen(
    modifier: Modifier, income: Long, expense: Long, balance: Long, budget: Long,
    items: List<Transaction>, onAdd: () -> Unit, onOpenTransactions: () -> Unit,
    onEdit: (Transaction) -> Unit
) {
    val monthExpenses = items.filter { it.type == "EXPENSE" && it.occurredAt.isSameMonth(Calendar.getInstance()) }
    val grouped = monthExpenses.groupBy { it.category }
        .mapValues { it.value.sumOf(Transaction::amountPaise) }.toList().sortedByDescending { it.second }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Net balance this month", style = MaterialTheme.typography.titleMedium)
                    Text(inr(balance), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        SummaryAmount("Income", income, "↑")
                        SummaryAmount("Expenses", expense, "↓")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Monthly expense budget", fontWeight = FontWeight.SemiBold)
                        Text(inr(budget))
                    }
                    val progress = if (budget > 0) expense.toFloat() / budget else 0f
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = if (progress > 1f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                    Text(
                        if (expense <= budget) "${inr(budget - expense)} remaining" else "${inr(expense - budget)} over budget",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item { SectionHeading("Spending by category") }
        if (grouped.isEmpty()) {
            item { EmptyHint("No expenses this month yet. Add one using +.") }
        } else {
            items(grouped) { (category, amount) ->
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(category)
                        Text(inr(amount), fontWeight = FontWeight.SemiBold)
                    }
                    LinearProgressIndicator(
                        progress = { if (expense > 0) (amount.toFloat() / expense).coerceIn(0f, 1f) else 0f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SectionHeading("Recent transactions")
                TextButton(onClick = onOpenTransactions) { Text("See all") }
            }
        }
        val recent = items.take(5)
        if (recent.isEmpty()) item { EmptyHint("Start by adding your first income or expense.") }
        items(recent, key = { it.id }) { item -> TransactionCard(item, onClick = { onEdit(item) }) }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun SummaryAmount(label: String, amount: Long, marker: String) {
    Column {
        Text("$marker $label", style = MaterialTheme.typography.labelMedium)
        Text(inr(amount), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun TransactionsScreen(
    modifier: Modifier, items: List<Transaction>,
    onEdit: (Transaction) -> Unit, onDelete: (Transaction) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf("ALL") }
    var period by remember { mutableStateOf("This month") }
    val now = Calendar.getInstance()
    val filtered = items.filter { item ->
        val matchesQuery = item.category.contains(query, true) ||
            item.note.contains(query, true) || item.paymentMethod.contains(query, true)
        val matchesType = typeFilter == "ALL" || item.type == typeFilter
        val matchesPeriod = when (period) {
            "This month" -> item.occurredAt.isSameMonth(now)
            "This week" -> item.occurredAt.isThisWeek()
            else -> true
        }
        matchesQuery && matchesType && matchesPeriod
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { SectionHeading("Transactions") }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Search category, note or payment") },
                singleLine = true
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ALL", "EXPENSE", "INCOME").forEach { value ->
                    FilterChip(
                        selected = typeFilter == value,
                        onClick = { typeFilter = value },
                        label = { Text(when (value) { "ALL" -> "All"; "EXPENSE" -> "Expenses"; else -> "Income" }) }
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("This month", "This week", "All time").forEach { value ->
                    FilterChip(selected = period == value, onClick = { period = value }, label = { Text(value) })
                }
            }
        }
        item { Text("${filtered.size} records", style = MaterialTheme.typography.labelMedium) }
        if (filtered.isEmpty()) item { EmptyHint("No matching transactions.") }
        items(filtered, key = { it.id }) { item ->
            TransactionCard(item, onClick = { onEdit(item) }, onDelete = { onDelete(item) }, showDelete = true)
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun ReportsScreen(modifier: Modifier, items: List<Transaction>) {
    var range by remember { mutableStateOf("Monthly") }
    val now = Calendar.getInstance()
    val selected = items.filter {
        when (range) {
            "Weekly" -> it.occurredAt.isThisWeek()
            else -> it.occurredAt.isSameMonth(now)
        }
    }
    val income = selected.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
    val expense = selected.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
    val maxDaily = selected.filter { it.type == "EXPENSE" }
        .groupBy { dayLabel(it.occurredAt) }.mapValues { e -> e.value.sumOf { it.amountPaise } }
    val categories = selected.filter { it.type == "EXPENSE" }.groupBy { it.category }
        .mapValues { e -> e.value.sumOf { it.amountPaise } }.toList().sortedByDescending { it.second }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionHeading("Reports & analytics") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Weekly", "Monthly").forEach {
                    FilterChip(selected = range == it, onClick = { range = it }, label = { Text(it) })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Income", income, Modifier.weight(1f))
                MetricCard("Expenses", expense, Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Net savings", style = MaterialTheme.typography.titleMedium)
                    Text(inr(income - expense), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Income minus expenses for the selected period", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { SectionHeading("Daily expense trend") }
        if (maxDaily.isEmpty()) item { EmptyHint("No expense data for this period.") }
        else {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        val entries = maxDaily.entries.sortedBy { it.key }
                        val peak = (entries.maxOfOrNull { it.value } ?: 1L).coerceAtLeast(1L)
                        entries.forEach { entry ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(entry.key, modifier = Modifier.width(76.dp), style = MaterialTheme.typography.labelSmall)
                                Box(Modifier.weight(1f).height(12.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))) {
                                    Box(
                                        Modifier.fillMaxWidth((entry.value.toFloat() / peak).coerceIn(0f, 1f))
                                            .fillMaxHeight().background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                                    )
                                }
                                Text(inr(entry.value), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
        item { SectionHeading("Category breakdown") }
        if (categories.isEmpty()) item { EmptyHint("No category data yet.") }
        items(categories) { (category, amount) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(category)
                Text(inr(amount), fontWeight = FontWeight.SemiBold)
            }
            LinearProgressIndicator(
                progress = { if (expense > 0) (amount.toFloat() / expense).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier, budget: Long, onBudget: () -> Unit,
    onBackup: () -> Unit, onRestore: () -> Unit
) {
    Column(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeading("Settings")
        Card(Modifier.fillMaxWidth().clickable(onClick = onBudget)) {
            Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Monthly expense budget", fontWeight = FontWeight.SemiBold)
                    Text("Current: ${inr(budget)}", style = MaterialTheme.typography.bodySmall)
                }
                Text("Change  ›", color = MaterialTheme.colorScheme.primary)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Data & backup", fontWeight = FontWeight.SemiBold)
                Text("Your transactions are stored on this device. Save a backup file somewhere safe so you can restore it later.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text("Export backup") }
                OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Text("Restore from backup") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("About PaisaTrack", fontWeight = FontWeight.SemiBold)
                Text("Version 2.0 · Offline-first · INR (₹)", style = MaterialTheme.typography.bodySmall)
                Text("No sign-in or bank connection. Enter transactions manually.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun TransactionEditor(
    existing: Transaction?, onDismiss: () -> Unit, onSave: (Transaction) -> Unit
) {
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: "EXPENSE") }
    var amount by remember(existing?.id) {
        mutableStateOf(existing?.let { String.format(Locale.US, "%.2f", it.amountPaise / 100.0) } ?: "")
    }
    var category by remember(existing?.id) { mutableStateOf(existing?.category ?: expenseCategories.first()) }
    var payment by remember(existing?.id) { mutableStateOf(existing?.paymentMethod ?: paymentMethods.first()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note ?: "") }
    var dateMillis by remember(existing?.id) { mutableLongStateOf(existing?.occurredAt ?: System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var paymentExpanded by remember { mutableStateOf(false) }
    val categories = if (type == "INCOME") incomeCategories else expenseCategories
    if (category !in categories) category = categories.first()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add transaction" else "Edit transaction") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 560.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == "EXPENSE", onClick = { type = "EXPENSE" }, label = { Text("Expense") })
                    FilterChip(selected = type == "INCOME", onClick = { type = "INCOME" }, label = { Text("Income") })
                }
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(
                        value = category, onValueChange = {}, readOnly = true,
                        label = { Text("Category") }, modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        categories.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false })
                        }
                    }
                }
                ExposedDropdownMenuBox(expanded = paymentExpanded, onExpandedChange = { paymentExpanded = !paymentExpanded }) {
                    OutlinedTextField(
                        value = payment, onValueChange = {}, readOnly = true,
                        label = { Text("Payment method") }, modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = paymentExpanded, onDismissRequest = { paymentExpanded = false }) {
                        paymentMethods.forEach { p ->
                            DropdownMenuItem(text = { Text(p) }, onClick = { payment = p; paymentExpanded = false })
                        }
                    }
                }
                OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Date: ${formatDate(dateMillis)}")
                }
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Note (optional)") }, singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val paise = amount.toPaiseOrNull()
                if (paise != null && paise > 0) {
                    onSave(Transaction(
                        id = existing?.id ?: 0,
                        amountPaise = paise, type = type, category = category,
                        paymentMethod = payment, note = note.trim(), occurredAt = dateMillis
                    ))
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )

    if (showDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = dateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { dateMillis = it }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
private fun TransactionCard(
    item: Transaction, onClick: () -> Unit, onDelete: (() -> Unit)? = null,
    showDelete: Boolean = false
) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.size(42.dp).background(
                    if (item.type == "INCOME") MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.secondaryContainer, CircleShape
                ),
                contentAlignment = Alignment.Center
            ) { Text(if (item.type == "INCOME") "+" else "−", fontWeight = FontWeight.Bold) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(item.category, fontWeight = FontWeight.SemiBold)
                Text(
                    listOf(item.paymentMethod, formatDate(item.occurredAt), item.note)
                        .filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    (if (item.type == "INCOME") "+" else "−") + inr(item.amountPaise),
                    fontWeight = FontWeight.Bold,
                    color = if (item.type == "INCOME") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                if (showDelete && onDelete != null) {
                    TextButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                } else {
                    Text("Tap to edit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, amount: Long, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(inr(amount), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionHeading(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable
private fun EmptyHint(text: String) {
    Card(Modifier.fillMaxWidth()) {
        Text(text, Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun Long.isSameMonth(calendar: Calendar): Boolean {
    val c = Calendar.getInstance().apply { timeInMillis = this@isSameMonth }
    return c.get(Calendar.YEAR) == calendar.get(Calendar.YEAR) &&
        c.get(Calendar.MONTH) == calendar.get(Calendar.MONTH)
}

private fun Long.isThisWeek(): Boolean {
    val c = Calendar.getInstance().apply { timeInMillis = this@isThisWeek }
    val now = Calendar.getInstance()
    return c.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
        c.get(Calendar.WEEK_OF_YEAR) == now.get(Calendar.WEEK_OF_YEAR)
}

private fun formatDate(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(millis))

private fun dayLabel(millis: Long): String =
    SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(millis))

private fun inr(paise: Long): String =
    "₹" + String.format(Locale("en", "IN"), "%,.2f", paise / 100.0)

private fun String.toPaiseOrNull(): Long? = runCatching {
    trim().toBigDecimal().movePointRight(2).longValueExact()
}.getOrNull()

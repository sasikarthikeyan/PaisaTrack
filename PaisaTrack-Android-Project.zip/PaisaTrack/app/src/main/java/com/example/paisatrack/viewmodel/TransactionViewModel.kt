package com.example.paisatrack.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.paisatrack.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TransactionViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = TransactionRepository(AppDatabase.get(app).transactionDao())
    val transactions = repository.transactions.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )

    fun save(item: Transaction) = viewModelScope.launch {
        if (item.amountPaise <= 0) return@launch
        if (item.id == 0L) repository.add(item) else repository.update(item)
    }
    fun delete(item: Transaction) = viewModelScope.launch { repository.delete(item) }
    fun restore(items: List<Transaction>) = viewModelScope.launch { repository.replaceAll(items) }
}

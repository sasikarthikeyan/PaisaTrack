package com.example.paisatrack.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY occurredAt DESC, id DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Insert
    suspend fun insert(item: Transaction)

    @Update
    suspend fun update(item: Transaction)

    @Delete
    suspend fun delete(item: Transaction)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(items: List<Transaction>)

    @androidx.room.Transaction
    suspend fun replaceAll(items: List<Transaction>) {
        clearAll()
        insertAll(items)
    }
}

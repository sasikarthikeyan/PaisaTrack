package com.example.paisatrack.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountPaise: Long,
    val type: String,              // INCOME or EXPENSE
    val category: String,
    val paymentMethod: String,
    val note: String,
    val occurredAt: Long
)

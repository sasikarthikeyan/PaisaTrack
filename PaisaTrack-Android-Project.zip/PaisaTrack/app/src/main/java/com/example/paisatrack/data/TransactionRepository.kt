package com.example.paisatrack.data

class TransactionRepository(private val dao: TransactionDao) {
    val transactions = dao.observeAll()
    suspend fun add(item: Transaction) = dao.insert(item)
    suspend fun update(item: Transaction) = dao.update(item)
    suspend fun delete(item: Transaction) = dao.delete(item)
    suspend fun replaceAll(items: List<Transaction>) = dao.replaceAll(items)
}
